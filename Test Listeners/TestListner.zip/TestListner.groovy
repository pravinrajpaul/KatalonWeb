import org.openqa.selenium.WebDriver

import com.kms.katalon.core.annotation.AfterTestCase
import com.kms.katalon.core.annotation.AfterTestSuite
import com.kms.katalon.core.annotation.BeforeTestCase
import com.kms.katalon.core.annotation.BeforeTestSuite
import com.kms.katalon.core.context.TestCaseContext
import com.kms.katalon.core.context.TestSuiteContext
import com.kms.katalon.core.webui.driver.DriverFactory

class TestListner {

		@AfterTestCase
	def afterTestCase(TestCaseContext testCaseContext) {
		WebDriver wd = DriverFactory.getWebDriver()
		wd.quit()
	}

}